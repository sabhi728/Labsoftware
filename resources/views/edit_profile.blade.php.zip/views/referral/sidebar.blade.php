<div class="webSidebar">
    <ul>
        <li onclick="goToRoute('referralpanel/home')" class="{{ request()->is('referralpanel/home') ? 'li_active' : '' }}">
            <a><i class='bx bxs-dashboard'></i><span>Dashboard</span></a>
        </li>
        <li onclick="goToRoute('referralpanel/orderentry/index')" class="{{ request()->is('referralpanel/orderentry/index') ? 'li_active' : '' }}">
            <a><i class='bx bx bxs-message-square-add'></i><span>Order Entry</span></a>
        </li>
        <li onclick="goToRoute('referralpanel/sample-status')" class="{{ request()->is('referralpanel/sample-status') ? 'li_active' : '' }}">
            <a><i class='bx bx bxs-package'></i><span>Sample Status</span></a>
        </li>
        <li onclick="goToRoute('referralpanel/submitted-sample')" class="{{ request()->is('referralpanel/submitted-sample') ? 'li_active' : '' }}">
            <a><i class='bx bx bxs-package'></i><span>Submitted Samples</span></a>
        </li>
        {{-- <li onclick="goToRoute('referralpanel/company-invoice')" class="{{ request()->is('referralpanel/company-invoice') ? 'li_active' : '' }}">
            <a><i class='bx bx-money-withdraw'></i><span>Company Invoice</span></a>
        </li> --}}
        <li onclick="goToRoute('referralpanel/contact-us')" class="{{ request()->is('referralpanel/contact-us') ? 'li_active' : '' }}">
            <a><i class='bx bxs-phone'></i><span>Contact Us</span></a>
        </li>
    </ul>
</div>
