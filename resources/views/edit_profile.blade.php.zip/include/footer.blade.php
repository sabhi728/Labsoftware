<footer>
    <copyright>© 2023 {{ env('WEBSITE_NAME') }}. All rights reserved.</copyright>
</footer>